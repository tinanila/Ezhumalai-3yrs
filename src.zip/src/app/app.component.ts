import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet} from '@ionic/angular/standalone';
import { IonicModule } from '@ionic/angular';
import { HomePage } from './home/home.page';
import { CommonModule } from '@angular/common';
import { DynamicColResizeDirective } from './dynamic-col-size.directive';
import { addIcons } from 'ionicons';
import { logoIonic } from 'ionicons/icons';
import {NavController } from '@ionic/angular';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  standalone: true,
  providers:[NavController, HttpClient],
  imports: [IonicModule, CommonModule, DynamicColResizeDirective],
})
export class AppComponent {
  constructor() {
    addIcons({ logoIonic });
  }
  
}
