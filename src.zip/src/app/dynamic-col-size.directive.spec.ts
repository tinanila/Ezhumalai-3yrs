import { DynamicColSizeDirective } from './dynamic-col-size.directive';

describe('DynamicColSizeDirective', () => {
  it('should create an instance', () => {
    const directive = new DynamicColSizeDirective();
    expect(directive).toBeTruthy();
  });
});
