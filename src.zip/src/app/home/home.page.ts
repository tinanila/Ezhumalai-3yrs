import { Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular/standalone';
import { StudentAttendanceComponent } from '../student-attendance/student-attendance.component';
import { AssessmentProgressComponent } from '../assessment-progress/assessment-progress.component';
import { CourseInfoComponent } from '../course-info/course-info.component';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { DynamicColResizeDirective } from '../dynamic-col-size.directive';
import {NavController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  providers:[NavController],
  imports: [IonicModule, CommonModule, DynamicColResizeDirective,  StudentAttendanceComponent, AssessmentProgressComponent, CourseInfoComponent],
})
export class HomePage {

  homeChoosen: boolean = true;
  settingsChoosen: boolean = false;
  constructor(
    private router: NavController
  ) {}

  highlight(menu:any){

    if(menu === 'home'){
       this.homeChoosen = true;
       this.settingsChoosen = false;
       //this.router.navigateRoot(['/home'])
    }else if(menu === 'settings'){
      this.settingsChoosen = true; 
      this.homeChoosen = false;
      //this.router.navigateRoot(['/settings'])
    }
  }
}
