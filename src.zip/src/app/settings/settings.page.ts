import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule , NavController} from '@ionic/angular';
import { IonContent, IonHeader, IonTitle, IonToolbar } from '@ionic/angular/standalone';
import { DynamicColResizeDirective } from '../dynamic-col-size.directive';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
  standalone: true,
  providers:[NavController],
  imports: [IonicModule, CommonModule, DynamicColResizeDirective],
})
export class SettingsPage implements OnInit {

  constructor(
    private router: NavController
  ) {}

  ngOnInit() {
  }

  

}
