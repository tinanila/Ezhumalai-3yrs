import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import * as jsonData from 'src/assets/linegraph.json';

@Component({
  selector: 'app-student-attendance',
  templateUrl: './student-attendance.component.html',
  styleUrls: ['./student-attendance.component.scss'],
  imports: [IonicModule, CommonModule],
  standalone: true
})
export class StudentAttendanceComponent implements OnInit, AfterViewInit {

  data: any = jsonData;

  

  constructor() {
    // Register Chart.js components (scales, elements, controllers, etc.)
    Chart.register(...registerables);
  }

  ngOnInit(){
    console.log('Json Line graph Data', this.data.dataSets);
  }



  ngAfterViewInit() {
    this.renderAttendanceChart();
  }

  renderAttendanceChart() {
    // Get the canvas element by id and its context
    const ctx:any = (document.getElementById('attendanceChart') as HTMLCanvasElement).getContext('2d');
    
    // Initialize the Chart with the canvas context
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: this.data.dataSets.labels,
        datasets: this.data.dataSets.datasets
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Attendance',  // Overall X-axis title
              font: {
                size: 14,  // Optional: Change font size for the x-axis title
                weight: 'bold'  // Optional: Make the x-axis title bold
              }
            },
            ticks: {
              stepSize:20,
              callback: function(value) {
                  return value + '%'; // Adds % to y-axis labels
              }
          },
            max: 100
          },
          x:{
            title: {
              display: true,
              text: 'Weeks',  // Overall X-axis title
              font: {
                size: 14,  // Optional: Change font size for the x-axis title
                weight: 'bold'  // Optional: Make the x-axis title bold
              }
            }
          }
          
        },
        plugins:{
          legend: {
            display: false  // Hide the legend
          }
        }
      }
    });
  }
}
